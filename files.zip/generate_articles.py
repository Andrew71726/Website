#!/usr/bin/env python3
"""
Generates SEO articles for the Malaysia Insights static blog.

Reads long-tail keywords from keywords.txt, calls the GPT-4o API to write an
800-1200 word article per keyword with APA-style references from UKM,
Malaysian government, WHO or MDPI sources, fills articles-template.html, saves
the result into articles/, updates articles/articles.json, and rebuilds
sitemap.xml from sitemap-template.xml.

Setup:
    pip install -r requirements.txt
    export OPENAI_API_KEY="sk-..."          (Linux/macOS)
    setx OPENAI_API_KEY "sk-..."            (Windows)

Usage:
    python generate_articles.py
    python generate_articles.py --limit 5 --delay 3
"""

import argparse
import html
import json
import logging
import os
import re
import sys
import time
from datetime import date, datetime, timezone
from pathlib import Path

import requests

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

try:
    from openai import OpenAI
except ImportError:
    print("Missing dependency. Run: pip install -r requirements.txt")
    sys.exit(1)

BASE_DIR = Path(__file__).resolve().parent
KEYWORDS_FILE = BASE_DIR / "keywords.txt"
TEMPLATE_FILE = BASE_DIR / "articles-template.html"
SITEMAP_TEMPLATE_FILE = BASE_DIR / "sitemap-template.xml"
SITEMAP_OUTPUT_FILE = BASE_DIR / "sitemap.xml"
ARTICLES_DIR = BASE_DIR / "articles"
MANIFEST_FILE = ARTICLES_DIR / "articles.json"

SITE_URL = os.environ.get("SITE_URL", "https://example.com").rstrip("/")

ALLOWED_DOMAIN_FRAGMENTS = ("ukm.edu.my", "gov.my", "who.int", "mdpi.com")

SYSTEM_PROMPT = (
    "You are an expert SEO content writer specializing in Malaysia-focused "
    "topics. You write factually accurate, well-structured English articles "
    "and only cite sources you are confident are real and accessible."
)

USER_PROMPT_TEMPLATE = """Write an SEO-optimized English blog article for the long-tail keyword: "{keyword}"

Requirements:
- Audience: general readers in Malaysia.
- Length: 800 to 1200 words for the main body content (excluding references).
- Structure the body using HTML tags only: <h2>, <h3>, <p>, <ul>/<li> where useful. Do not include <html>, <head>, <body>, or <h1> tags.
- Naturally include the target keyword and closely related terms for SEO, without keyword stuffing.
- Tone: clear, trustworthy, informative.
- Include exactly 3 to 5 real, verifiable references published by one of these source types only:
  1. Universiti Kebangsaan Malaysia (UKM) journals (URL contains "ukm.edu.my")
  2. Official Malaysian government websites (URL contains "gov.my")
  3. World Health Organization (URL contains "who.int")
  4. MDPI journals (URL contains "mdpi.com")
- Each reference must be a real, currently accessible URL. Do not invent or guess a URL. If you are not fully confident a URL is real and correct, omit that reference instead of fabricating it.
- Format each citation in APA style (Author/Organization, Year, Title, Source), without the URL inside the citation text.

Return ONLY a valid JSON object, no markdown fences, no extra text, matching exactly this schema:
{{
  "title": "compelling SEO title, under 70 characters",
  "meta_description": "under 160 characters",
  "main_content_html": "the full HTML body described above",
  "references": [
    {{"citation": "APA-style citation text without the URL", "url": "https://..."}}
  ]
}}
"""

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("generate_articles")


def get_client() -> OpenAI:
    if not os.environ.get("OPENAI_API_KEY"):
        log.error("OPENAI_API_KEY environment variable is not set. Aborting.")
        sys.exit(1)
    return OpenAI()


def read_keywords(path: Path) -> list:
    if not path.exists():
        log.error("Keywords file not found: %s", path)
        return []
    keywords = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            keywords.append(line)
    return keywords


def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", "-", text).strip("-")
    return text[:80] or "article"


def unique_slug(base_slug: str, taken: set) -> str:
    if base_slug not in taken:
        return base_slug
    suffix = 2
    while f"{base_slug}-{suffix}" in taken:
        suffix += 1
    return f"{base_slug}-{suffix}"


def call_gpt4o(client: OpenAI, keyword: str, model: str, max_retries: int = 3) -> dict:
    required_keys = {"title", "meta_description", "main_content_html", "references"}
    for attempt in range(1, max_retries + 1):
        try:
            response = client.chat.completions.create(
                model=model,
                temperature=0.7,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": USER_PROMPT_TEMPLATE.format(keyword=keyword)},
                ],
            )
            content = response.choices[0].message.content
            data = json.loads(content)
            if not required_keys.issubset(data.keys()):
                raise ValueError(f"Response missing keys: {required_keys - data.keys()}")
            if not isinstance(data.get("references"), list):
                raise ValueError("references field is not a list")
            return data
        except (json.JSONDecodeError, ValueError) as e:
            log.warning("Attempt %d/%d for '%s' produced invalid output: %s", attempt, max_retries, keyword, e)
        except Exception as e:
            log.warning("Attempt %d/%d for '%s' failed: %s", attempt, max_retries, keyword, e)
        time.sleep(2 * attempt)
    return None


def is_allowed_domain(url: str) -> bool:
    return any(fragment in url.lower() for fragment in ALLOWED_DOMAIN_FRAGMENTS)


def url_is_accessible(url: str, timeout: int = 8) -> bool:
    headers = {"User-Agent": "Mozilla/5.0 (compatible; MalaysiaInsightsBot/1.0)"}
    try:
        resp = requests.head(url, allow_redirects=True, timeout=timeout, headers=headers)
        if resp.status_code < 400:
            return True
        resp = requests.get(url, allow_redirects=True, timeout=timeout, headers=headers, stream=True)
        return resp.status_code < 400
    except requests.RequestException:
        return False


def validate_references(references: list) -> list:
    valid = []
    for ref in references:
        url = str(ref.get("url", "")).strip()
        citation = str(ref.get("citation", "")).strip()
        if not url or not citation:
            continue
        if not is_allowed_domain(url):
            log.warning("Dropping reference outside allowed domains: %s", url)
            continue
        if url_is_accessible(url):
            valid.append({"citation": citation, "url": url})
        else:
            log.warning("Dropping unreachable reference URL: %s", url)
    return valid


def build_reference_html(references: list) -> str:
    items = []
    for ref in references:
        citation = html.escape(ref["citation"])
        url = html.escape(ref["url"], quote=True)
        items.append(f'<li>{citation} <a href="{url}" target="_blank" rel="noopener noreferrer">{url}</a></li>')
    return "\n        ".join(items)


def fill_template(template: str, mapping: dict) -> str:
    result = template
    for key, value in mapping.items():
        result = result.replace("{{" + key + "}}", value)
    return result


def load_manifest() -> list:
    if MANIFEST_FILE.exists():
        try:
            return json.loads(MANIFEST_FILE.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            log.warning("articles.json is corrupt, starting a new manifest")
    return []


def save_manifest(manifest: list) -> None:
    MANIFEST_FILE.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")


def rebuild_sitemap(manifest: list) -> None:
    template = SITEMAP_TEMPLATE_FILE.read_text(encoding="utf-8")
    entries = []
    for article in manifest:
        entries.append(
            "  <url>\n"
            f"    <loc>{SITE_URL}/{article['url']}</loc>\n"
            f"    <lastmod>{article['publish_date']}</lastmod>\n"
            "    <changefreq>monthly</changefreq>\n"
            "    <priority>0.8</priority>\n"
            "  </url>"
        )
    sitemap = fill_template(
        template,
        {
            "SITE_URL": SITE_URL,
            "LAST_MODIFIED": date.today().isoformat(),
            "ARTICLE_URL_ENTRIES": "\n".join(entries),
        },
    )
    SITEMAP_OUTPUT_FILE.write_text(sitemap, encoding="utf-8")


def word_count(html_content: str) -> int:
    text = re.sub(r"<[^>]+>", " ", html_content)
    return len(text.split())


def process_keyword(client: OpenAI, keyword: str, model: str, template: str, manifest: list, taken_slugs: set) -> bool:
    base_slug = slugify(keyword)
    if base_slug in taken_slugs:
        log.info("Skipping '%s', already published as %s", keyword, base_slug)
        return False

    data = call_gpt4o(client, keyword, model)
    if not data:
        log.error("Giving up on '%s' after repeated failures", keyword)
        return False

    valid_refs = validate_references(data["references"])
    if len(valid_refs) < 3:
        log.warning("Only %d verified references for '%s', retrying once", len(valid_refs), keyword)
        retry_data = call_gpt4o(client, keyword, model, max_retries=1)
        if retry_data:
            retry_refs = validate_references(retry_data["references"])
            if len(retry_refs) > len(valid_refs):
                data, valid_refs = retry_data, retry_refs

    if not valid_refs:
        log.error("No verifiable references found for '%s', skipping article", keyword)
        return False
    if len(valid_refs) < 3:
        log.warning("Publishing '%s' with only %d verified reference(s)", keyword, len(valid_refs))

    slug = unique_slug(base_slug, taken_slugs)
    publish_date = date.today().isoformat()
    canonical_url = f"{SITE_URL}/articles/{slug}.html"
    main_content = data["main_content_html"]

    wc = word_count(main_content)
    if not 800 <= wc <= 1200:
        log.warning("'%s' article is %d words, outside the 800-1200 target", keyword, wc)

    article_html = fill_template(
        template,
        {
            "title": html.escape(data["title"]),
            "meta_description": html.escape(data["meta_description"]),
            "canonical_url": canonical_url,
            "publish_date": publish_date,
            "main_content": main_content,
            "reference_list": build_reference_html(valid_refs),
        },
    )

    output_path = ARTICLES_DIR / f"{slug}.html"
    output_path.write_text(article_html, encoding="utf-8")
    log.info("Saved %s (%d words, %d references)", output_path.name, wc, len(valid_refs))

    manifest.append(
        {
            "title": data["title"],
            "slug": slug,
            "publish_date": publish_date,
            "description": data["meta_description"],
            "url": f"articles/{slug}.html",
            "keyword": keyword,
        }
    )
    taken_slugs.add(slug)
    save_manifest(manifest)
    rebuild_sitemap(manifest)
    return True


def main():
    parser = argparse.ArgumentParser(description="Generate SEO articles from keywords.txt using GPT-4o")
    parser.add_argument("--keywords-file", default=str(KEYWORDS_FILE))
    parser.add_argument("--model", default="gpt-4o")
    parser.add_argument("--limit", type=int, default=None, help="Max number of new articles to generate this run")
    parser.add_argument("--delay", type=float, default=2.0, help="Seconds to wait between API calls")
    args = parser.parse_args()

    if not TEMPLATE_FILE.exists():
        log.error("Missing %s", TEMPLATE_FILE.name)
        sys.exit(1)
    if not SITEMAP_TEMPLATE_FILE.exists():
        log.error("Missing %s", SITEMAP_TEMPLATE_FILE.name)
        sys.exit(1)
    ARTICLES_DIR.mkdir(exist_ok=True)

    keywords = read_keywords(Path(args.keywords_file))
    if not keywords:
        log.error("No keywords found in %s", args.keywords_file)
        sys.exit(1)

    client = get_client()
    template = TEMPLATE_FILE.read_text(encoding="utf-8")
    manifest = load_manifest()
    taken_slugs = {article["slug"] for article in manifest}

    generated = 0
    for keyword in keywords:
        if args.limit is not None and generated >= args.limit:
            log.info("Reached limit of %d new articles, stopping", args.limit)
            break
        if process_keyword(client, keyword, args.model, template, manifest, taken_slugs):
            generated += 1
            time.sleep(args.delay)

    log.info("Done. %d new article(s) generated out of %d keyword(s).", generated, len(keywords))


if __name__ == "__main__":
    main()
