# Malaysia Insights - Static SEO Blog

A static, SEO-friendly blog website built for Malaysian readers. New articles are added as plain HTML files by a Python script, and the homepage plus sitemap update automatically from data files the script maintains.

## Directory structure

```
├── index.html                 Homepage, lists all published articles
├── articles-template.html     Template for new articles (placeholders below)
├── css/style.css              All styling
├── js/script.js                Homepage article loader + shared behaviour
├── articles/                  Generated article .html files go here
│   └── articles.json          Manifest the homepage reads to build its list
├── sitemap-template.xml       Template the Python script fills to produce sitemap.xml
└── README.md
```

## How the homepage auto-updates

`index.html` does not read the `articles/` folder directly (browsers cannot list a
folder's contents). Instead it fetches `articles/articles.json`, a small manifest file,
and renders one card per entry, sorted by publish date (newest first).

Every time the Python script adds a new article `.html` file to `articles/`, it must
also append a matching entry to `articles/articles.json`:

```json
[
  {
    "title": "Article Title",
    "slug": "article-title",
    "publish_date": "2026-07-17",
    "description": "One or two sentence summary shown on the homepage card.",
    "url": "articles/article-title.html"
  }
]
```

No other homepage changes are needed — `js/script.js` reads this file on every page load.

Note: `fetch()` requires the site to be served over HTTP (e.g. `python -m http.server`,
Nginx, GitHub Pages, Netlify, etc). Opening `index.html` directly via `file://` will
block the fetch due to browser CORS restrictions.

## articles-template.html placeholders

The Python script should copy this template into `articles/<slug>.html` and replace:

| Placeholder            | Description                                              |
|-------------------------|-----------------------------------------------------------|
| `{{title}}`             | Article title, used in `<title>`, `<h1>` and OG tags      |
| `{{meta_description}}`  | 1–2 sentence SEO meta description                         |
| `{{canonical_url}}`     | Full canonical URL of the published article                |
| `{{publish_date}}`      | ISO date, e.g. `2026-07-17`                                 |
| `{{main_content}}`      | Full article body HTML (headings, paragraphs, images, etc) |
| `{{reference_list}}`    | One or more `<li>` items, see format below                 |

## Reference format (Google E-E-A-T)

Each reference must be a list item in APA style with a clickable source link, e.g.:

```html
<li>
  Ministry of Health Malaysia. (2025). Guidelines on dengue prevention.
  <a href="https://www.moh.gov.my/dengue-guidelines" target="_blank" rel="noopener noreferrer">
    https://www.moh.gov.my/dengue-guidelines
  </a>
</li>
```

Join all reference `<li>` items into a single string and insert it in place of
`{{reference_list}}` inside the `<ol class="reference-list">` block.

## sitemap-template.xml placeholders

| Placeholder                | Description                                          |
|------------------------------|-------------------------------------------------------|
| `{{SITE_URL}}`               | Base site URL, e.g. `https://example.com`             |
| `{{LAST_MODIFIED}}`          | Last modification date of the homepage                |
| `{{ARTICLE_URL_ENTRIES}}`    | One `<url>` block per article, appended here          |

Each article entry should follow this format before being joined together and
substituted into `{{ARTICLE_URL_ENTRIES}}`:

```xml
<url>
  <loc>{{SITE_URL}}/articles/{{slug}}.html</loc>
  <lastmod>{{publish_date}}</lastmod>
  <changefreq>monthly</changefreq>
  <priority>0.8</priority>
</url>
```

The script should write the final result to `sitemap.xml` at the project root
(keep `sitemap-template.xml` untouched so it can be reused).

## Python script workflow (suggested)

1. Generate article HTML from `articles-template.html`, filling all placeholders.
2. Save it as `articles/<slug>.html`.
3. Append a matching entry to `articles/articles.json`.
4. Rebuild `sitemap.xml` from `sitemap-template.xml` using the full article list.
5. Deploy/upload the updated files.

## Design notes

- Mobile-first, responsive layout using CSS Grid (`css/style.css`).
- No external frameworks or fonts required — works fully offline once deployed.
- `en-MY` locale set on all pages; dates render in Malaysian long-date format.
- Update the placeholder domain `https://example.com` in `index.html`'s canonical
  link and social meta tags to your real domain before going live.
