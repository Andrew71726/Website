document.addEventListener("DOMContentLoaded", function () {
  var yearEl = document.getElementById("current-year");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  var listEl = document.getElementById("article-list");
  if (listEl) {
    loadArticles(listEl);
  }
});

function loadArticles(listEl) {
  var emptyEl = document.getElementById("empty-state");

  fetch("articles/articles.json", { cache: "no-store" })
    .then(function (response) {
      if (!response.ok) {
        throw new Error("Manifest not found");
      }
      return response.json();
    })
    .then(function (articles) {
      renderArticles(listEl, emptyEl, articles);
    })
    .catch(function () {
      listEl.innerHTML = "";
      if (emptyEl) emptyEl.hidden = false;
    });
}

function renderArticles(listEl, emptyEl, articles) {
  listEl.innerHTML = "";

  if (!Array.isArray(articles) || articles.length === 0) {
    if (emptyEl) emptyEl.hidden = false;
    return;
  }

  var sorted = articles.slice().sort(function (a, b) {
    return new Date(b.publish_date) - new Date(a.publish_date);
  });

  sorted.forEach(function (article) {
    listEl.appendChild(buildCard(article));
  });
}

function buildCard(article) {
  var card = document.createElement("article");
  card.className = "article-card";

  var time = document.createElement("time");
  time.setAttribute("datetime", article.publish_date || "");
  time.textContent = formatDate(article.publish_date);

  var heading = document.createElement("h2");
  var link = document.createElement("a");
  link.href = article.url;
  link.textContent = article.title || "Untitled article";
  heading.appendChild(link);

  var description = document.createElement("p");
  description.textContent = article.description || "";

  var readMore = document.createElement("a");
  readMore.className = "read-more";
  readMore.href = article.url;
  readMore.textContent = "Read more \u2192";

  card.appendChild(time);
  card.appendChild(heading);
  card.appendChild(description);
  card.appendChild(readMore);

  return card;
}

function formatDate(dateString) {
  if (!dateString) return "";
  var date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString;
  return date.toLocaleDateString("en-MY", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
}
